docker run --rm \
  -v $(pwd)/:/home/jenkins/test \
   --entrypoint '/home/jenkins/test/bats-core/bin/bats' \
   --user 1000:1000 \
   registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/jnlp-agent:latest test
