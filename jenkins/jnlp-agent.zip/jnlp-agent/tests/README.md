# Tests

Tests the container using [bats](https://github.com/bats-core/bats-core).

In order to execute the test submodule bats must be loaded. 


