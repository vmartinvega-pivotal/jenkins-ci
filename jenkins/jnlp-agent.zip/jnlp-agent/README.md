---
permalink: agents/jnlp.html
tags: [agent]
agentLabels: ''
summary: JNLP Agent base
---
# JNLP agent base

Jenskins default slave to be connected with through _JNLP_ protocol.

This agent is based on [jenkins/jnlp-slave](https://github.com/jenkinsci/docker-jnlp-slave) agent

Includes these tools:

* curl
* git
* jq
* kiuwan
* Open JDK 8
* sonar-runner
* sonar-scanner-cli 
* unzip
* wget
* yq

Creates this variables:

* AGENT_HOME: Kiuwan home directory (_/KiuwanLocalAnalyzer_)
* GIT_SSL_NO_VERIFY: Git ssl no verify (0)
* GIT_TERMINAL_PROMPT: Disables git prompt (1)
* JAVA_HOME: Java home directory
* JENKINS_AGENT_HOME: Agent home directory (/home/jenkins)
* SONAR_RUNNER_VERSION: Sonar-runner version (_2.4_)
* SONAR_RUNNER_HOME: Sonar runner home (_/usr/share/sonar-runner_)
* SONAR_USER_HOME: Sonar user directory (_${JENKINS_AGENT_HOME}/.sonar_)
* SONAR_SCANNER_HOME=/usr/share/sonar-scanner \
* SONAR_SCANNER_VERSION=3.2.0.1227
* AGENT_HOME: Kiuwan agent home (_/KiuwanLocalAnalyzer_)


 # Build

 ```
 docker build --build-arg HTTP_PROXY=${http_proxy} -t registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/jnlp-agent .
 ```

 These arguments can be defined at build time

 | argument | required    | description |
 | -------- | ----------- | ----------- |
 | HTTP_PROXY | no | Http proxy to build the image |

