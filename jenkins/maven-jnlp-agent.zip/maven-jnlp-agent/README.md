---
permalink: agents/maven.html
tags: [agent, maven, java]
agentLabels: maven
summary: JNLP Agent with maven 3
---
# Maven JNLP Agent

## Introduction

This agent extends [jnlp-agent]({{ site.url }}/agents/jnlp.html), thus it includes all its tools and variables. In addition, the container adds the following tools and environment variables:

* **Tools**:
  * Maven 3.6.3
  * JDK 11

* **Environment Variables**:
  * __MAVEN_HOME__: Maven installation directory (_/usr/share/maven_)
  * __MAVEN_CONFIG__: Maven .m2 directory ( _"${JENKINS_AGENT_HOME}/.m2"_)
  * __MAVEN_VERSION__: The version of Maven to be downloaded (_3.6.3_)
  * __MAVEN_SHA__: The expected SHA hash of the Maven distribution to be downloaded (_c35a1803a6e70a126e80b2b3ae33eed961f83ed74d18fcd16909b2d44d7dada3203f1ffe726c17ef8dcca2dcaa9fca676987befeadc9b9f759967a8cb77181c0_)
  * __BASE_URL__: The URL from where to download the Maven distribution at build time (_https://apache.osuosl.org/maven/maven-3/${MAVEN_VERSION}/binaries_)
  * __AGEN_VERSION__: The Docker tag of the released image.
  * __JDK_11_HOME__: Open JDK 11 home directory

If the environment variable *MVN_EXTENSION_URL* is defined then the Maven extension pointed by that URL will be downloaded and installed in the Maven extension directory at runtime.
A default value for the environment variable can be specified using the *MVN_EXTENSION_URL* build argument.

A default value for the *AGENT_VERSION* environment variable can be specified using the homonimous *AGENT_VERSION* build argument. By default, this argument is set as `registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent:latest`.

## Build

```shell
  docker build \
        --build-arg HTTP_PROXY="${http_proxy}" \
        -t registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent \
        .
```

or with a default Maven extension URL:

```shell
  docker build \
        --build-arg HTTP_PROXY="${http_proxy}" \
        --build-arg MVN_EXTENSION_URL="<url-to-extension>" \
        -t registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent \
        .
```

Please note that if no `http_proxy` environment variable is available, a value must be manually defined because the image requires so.

## Test

[BATS](https://github.com/bats-core/bats-core) is used for testing the container. Its sources are included as a submodule, thus, before running the tests it is necessary to initialize the local configuration file and to fetch the data from the repository:

```shell
$ git submodule init
Submodule 'tests/bats-core' (https://github.com/bats-core/bats-core) registered for path 'tests/bats-core'
$ git submodule update
Cloning into '/home/mestebangutierrez/development/alm-multi-cloud/maven-jnlp-agent/tests/bats-core'...
Submodule path 'tests/bats-core': checked out '8789f910812afbf6b87dd371ee5ae30592f1423f
```

Once the BATS submodule is ready, the tests can be run as follows:

```shell
$ pushd tests
~/development/alm-multi-cloud/maven-jnlp-agent/tests ~/development/alm-multi-cloud/maven-jnlp-agent
$ ./test.sh
Using ALM Global Maven Lifecycle Extension version 'almglobal-maven-lifecycle-1.3.0-20190626.155624-11.jar'...
Using ALM Global [PRO] Nexus instance as Maven mirror...
>> Launching BATS...
   |  WARNING: Your kernel does not support swap limit capabilities, memory limited without swap.
   |  Maven extension 'almglobal-maven-lifecycle-1.3.0-20190626.155624-11.jar' is not installed yet.
   |  Downloading Maven extension 'almglobal-maven-lifecycle-1.3.0-20190626.155624-11.jar':
   |    - Source url......: https://nexusmaster.alm.europe.cloudcenter.corp/repository/maven-snapshots/com/santander/alm/almglobal-maven-lifecycle/1.3.0-SNAPSHOT/almglobal-maven-lifecycle-1.3.0-20190626.155624-11.jar
   |    - Target directory: /usr/share/maven/lib/ext
######################################################################## 100.0%
   |  Maven extension 'almglobal-maven-lifecycle-1.3.0-20190626.155624-11.jar' installed successfully.
   |  1..8
   |  ok 1 home directory must be writable
   |  ok 2 default java command
   |  ok 3 JAVA_HOME environment variable must be set
   |  ok 4 maven must be installed
   |  ok 5 must install maven extension
   |  ok 6 java must compile the SSLPoke
   |  ok 7 test java cacerts
   |  ok 8 Must build a maven project from github
$ popd
~/development/alm-multi-cloud/maven-jnlp-agent
```

More details about the tests can be checked within the `README.md` file in the `tests` folder.

## Push

New image tags can be pushed to the registry as follows:

```shell
  docker push registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent
```

Remember to login into the registry before pushing.

## Run

The slave can be used in a standalone maner to run a local project as follows:

```shell
     docker run --rm \
        -e JAVA_OPTS="${JAVA_OPTS}" \
        -e MAVEN_OPTS="${MAVEN_OPTS}" \
        -v "<path-to-local-project>":/home/jenkins/workspace \
        -w "/home/jenkins/workspace"
        --user "$(id -u):$(id -g)" \
        registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent:latest sh -c 'mvn <maven-options-and-arguments>'
```

Please note that if no `JAVA_OPTS` or `MAVEN_OPTS`environment variable are not available (or they are but their values not desired for the in-container construction), and are required for the build they should be manually provided.

[Additional configuration is required](https://gitlab.alm.gsnetcloud.corp/serenity-alm/almglobal-maven-lifecycle/blob/master/README.md) if the ALM Global Maven Lifecycle Extension is to be used. This configuration can be specified as follows:

```shell
     docker run --rm \
        -e JAVA_OPTS="${JAVA_OPTS}" \
        -e MAVEN_OPTS="${MAVEN_OPTS}" \
        -e ATLAS_ENDPOINT="<target-atlas-endpoint>" \
        -e ATLAS_USERNAME="<target-atlas-username>" \
        -e ATLAS_SECRET="<target-atlas-password>" \
        -v "<path-to-local-project>":/home/jenkins/project \
        -w "/home/jenkins/workspace"
        --user "$(id -u):$(id -g)" \
        registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent:latest sh -c 'mvn <maven-options-and-arguments>'
```

To avoid leaking passwords in the command line, the Atlas configuration could be specified leveraging a file of environment variables as follows:

```shell
  $ cat <<- EOF > .atlas
      ATLAS_ENDPOINT=<target-atlas-endpoint>
      ATLAS_USERNAME=<target-atlas-username>
      ATLAS_SECRET=<target-atlas-password>
    EOF
  $ docker run --rm \
        -e JAVA_OPTS="${JAVA_OPTS}" \
        -e MAVEN_OPTS="${MAVEN_OPTS}" \
        --env-file .atlas
        -v "<path-to-local-project>":/home/jenkins/project \
        -w "/home/jenkins/workspace"
        --user "$(id -u):$(id -g)" \
        registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent:latest sh -c 'mvn <maven-options-and-arguments>'
```

In future versions support for secrets (either [Docker secrets](https://docs.docker.com/engine/swarm/secrets/) or [Kubernetes secrets](https://kubernetes.io/docs/concepts/configuration/secret/)) will be added.

Please not that the default ALM Global Maven Lifecycle Extension version can be overriden as follows:

```shell
  $ docker run --rm \
        -e JAVA_OPTS="${JAVA_OPTS}" \
        -e MAVEN_OPTS="${MAVEN_OPTS}" \
        -e MVN_EXTENSION_URL="<url-to-extension>" \
        --env-file .atlas
        -v "<path-to-local-project>":/home/jenkins/project \
        -w "/home/jenkins/workspace"
        --user "$(id -u):$(id -g)" \
        registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent:latest sh -c 'mvn <maven-options-and-arguments>'
```

## Kubernetes Configuration

Find below an example Kubernetes configuration:

```yml
    - containers:
      - alwaysPullImage: true
        args: "jenkins-slave ${computer.jnlpmac} ${computer.name}"
        command: "/usr/local/bin/mvn-entrypoint.sh"
        envVars:
        - envVar:
            key: "JAVA_OPTS"
            value: "-Xmx1700M"
        - envVar:
            key: "MAVEN_OPTS"
            value: "-Xmx1700M"
        image: "registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent"
        livenessProbe:
          execArgs: "mvn --version"
          failureThreshold: 0
          initialDelaySeconds: 0
          periodSeconds: 0
          successThreshold: 0
          timeoutSeconds: 0
        name: "jnlp"
        resourceLimitCpu: "1000m"
        resourceLimitMemory: "2Gi"
        resourceRequestCpu: "500m"
        resourceRequestMemory: "500Mi"
        ttyEnabled: true
      idleMinutes: 1
      idleMinutesStr: "1"
      instanceCap: 2
      instanceCapStr: "2"
      label: "maven maven3 java"
      name: "maven-jnlp-agent"
      slaveConnectTimeout: 300
      slaveConnectTimeoutStr: "300"
      workspaceVolume:
        emptyDirWorkspaceVolume:
          memory: false
```

And find below the same example but with the ALM Global Maven Lifecycle Extension configured:

```yml
    - containers:
      - alwaysPullImage: true
        args: "jenkins-slave ${computer.jnlpmac} ${computer.name}"
        command: "/usr/local/bin/mvn-entrypoint.sh"
        envVars:
        - envVar:
            key: "JAVA_OPTS"
            value: "-Xmx1700M"
        - envVar:
            key: "MAVEN_OPTS"
            value: "-Xmx1700M"
        - envVar:
            key: "MVN_EXTENSION_URL"
            value: "https://nexusmaster.alm.europe.cloudcenter.corp/repository/maven-snapshots/com/santander/alm/almglobal-maven-lifecycle/1.3.0-SNAPSHOT/almglobal-maven-lifecycle-1.3.0-20190617.081239-1.jar"
        - envVar:
            key: "ATLAS_ENDPOINT"
            value: "<target-atlas-endpoint>"
        - envVar:
            key: "ATLAS_USERNAME"
            value: "<target-atlas-username>"
        - envVar:
            key: "ATLAS_PASSWORD"
            value: "<target-atlas-password>"
        image: "registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent"
        livenessProbe:
          execArgs: "mvn --version"
          failureThreshold: 0
          initialDelaySeconds: 0
          periodSeconds: 0
          successThreshold: 0
          timeoutSeconds: 0
        name: "jnlp"
        resourceLimitCpu: "1000m"
        resourceLimitMemory: "2Gi"
        resourceRequestCpu: "500m"
        resourceRequestMemory: "500Mi"
        ttyEnabled: true
      idleMinutes: 1
      idleMinutesStr: "1"
      instanceCap: 2
      instanceCapStr: "2"
      label: "maven maven3 java"
      name: "maven-jnlp-agent"
      slaveConnectTimeout: 300
      slaveConnectTimeoutStr: "300"
      workspaceVolume:
        emptyDirWorkspaceVolume:
          memory: false

```

To avoid hard-wiring the Atlas password in the example above, the password could be provided leveraging a Kubernetes Secret mounted as the environment variable.
