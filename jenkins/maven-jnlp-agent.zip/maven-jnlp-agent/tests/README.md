# Tests

Tests the container using [bats](https://github.com/bats-core/bats-core).

## Running the tests

In order to run the tests, just execute the following command from this folder:

```shell
$ ./tests.sh
```

By default, the tests will use a specific ALM Global Maven Lifecycle Extension and the ALM Multi-Cloud [PRO] Nexus instance as Maven mirror. However both of these configuration details can be configured. More details can be obtained as follows:

```shell
$ ./test.sh --help
```

