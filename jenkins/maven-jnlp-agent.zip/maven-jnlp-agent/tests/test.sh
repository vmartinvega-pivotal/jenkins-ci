#!/bin/bash

set -eu

######
##
## Information methods
##
######

function showUsage() {
		while IFS="" read -r line; do
			echo -e "${line}"
		done <<- EOF
		USAGE: $(basename "$0") [OPTIONS]
		       $(basename "$0") [ -h | --help | -v | --version ]

		A simple client for testing the Maven JNLP Agent.

		Options:
		  -e, --extension ${CYAN}<URL>${RESET}  URL of the ALM Global Maven Lifecycle Extension version to download and install
		  -n, --nexus ${CYAN}<id>${RESET}       Identifier of the target Nexus instance to be used as mirror. It should be one of '${CYAN}alm-multi-cloud-pro${RESET}' or '${CYAN}alm-global-pro${RESET}'.

		  -h, --help             Print usage and quit
		  -v, --version          Print version information and quit

		  -q, --quiet            Only display minimal information
		  -V, --verbose          Print extended information
		  -D, --debug            Enable debug mode

		  --no-color             Disable color in output messages
	EOF
}

function showVersion() {
	echo "ALM Multi-Cloud :: Maven JNLP Agent Tester - v0.0.1"
}

######
##
## Bootstrap entrypoint
##
######

function pre_main() {
  while [[ $# -gt 0 ]]; do
    case "${1}" in
      --no-color)
          COLORIZE=0
          shift 1
          ;;
      -d|--debug)
          DEBUG=1
          shift 1
          ;;
      *)
        shift 1
        ;;
    esac
  done

	# shellcheck disable=SC1090
	source "$(basename "$0" ".sh").imports"
	if (( DEBUG )); then
		import "modules/error"
		set -E
		# shellcheck disable=SC2154
		trap 'panic "$-" "$LINENO" "$?"' ERR
	fi
}

######
##
## Bootstrap
##
######

readonly INSTALL_DIRECTORY="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

declare -i DEBUG=0
declare -i COLORIZE=1

pre_main "${@}"

import "modules/utils"

######
##
## Command line parsing & validation
##
######

declare -i VERBOSE=0
declare -i QUIET=0

extensionUrl=""
targetNexus=""
while [[ $# -gt 0 ]]; do
    case "${1}" in
        --no-color)
            # Ignore, already processed by now
            shift 1
            ;;
        -d|--debug)
            # Ignore, already processed by now
            shift 1
            ;;
        -V|--verbose)
            VERBOSE=1
            shift 1
            ;;
        -q|--quiet)
            QUIET=1
            shift 1
            ;;
        -v|--version)
            showVersion
            exit 0
            ;;
        -h|--help)
            showUsage
            exit 0
            ;;
        -e|--extension)
            if [[ $# -eq 1 ]]; then
                error "No Maven extension specified."
                exit 1
            fi
            extensionUrl="${2}"
            shift 2
            ;;
       -n|--nexus)
            if [[ $# -eq 1 ]]; then
                error "No target Nexus instance specified. It should be one of '${CYAN}alm-multi-cloud-pro${RESET}' or '${CYAN}alm-global-pro${RESET}'."
                exit 2
            fi
            targetNexus="${2}"
            shift 2
            ;;
        -*)
            error "Invalid configuration option '${YELLOW}${1}${RESET}'"
            exit 3
            ;;
        *)
            error "No arguments expected"
            exit 4
            ;;
    esac
done

(( QUIET )) && { VERBOSE=0; }

(( DEBUG )) && {
	(( DEBUG    )) && { debug "Debug mode is enabled";    }
	(( QUIET    )) && { debug "Quiet mode is enabled";    }
	(( VERBOSE  )) && { debug "Verbose mode is enabled";  }
	(( COLORIZE )) && { debug "Colorize mode is enabled"; }
}

######
##
## Initialization
##
######

if [[ -z "${extensionUrl}" ]]; then
  verbose "No specific ALM Global Maven Lifecycle Extension version URL specified. Falling back to default version URL..."
  extensionUrl="https://nexus.alm.gsnetcloud.corp/repository/maven-releases/com/santander/alm/almglobal-maven-lifecycle/1.3.0/almglobal-maven-lifecycle-1.3.0.jar"
fi

extensionName="${extensionUrl##*/}"
info "Using ALM Global Maven Lifecycle Extension version '${GREEN}${extensionName}${RESET}'..."

if [[ -z "${targetNexus}" ]]; then
  verbose "No specific target Nexus instance specified to be used as Maven mirror. Falling back to using the default target Nexus instance as Maven mirror..."
  targetNexus="alm-multi-cloud-pro"
fi

case "${targetNexus}" in
  "alm-multi-cloud-pro")
    info "Using ${GREEN}ALM Multi-Cloud [PRO] Nexus${RESET} instance as Maven mirror..."
    nexusMirror="https://nexus.alm.europe.cloudcenter.corp"
    ;;
  "alm-global-pro")
    info "Using ${GREEN}ALM Global [PRO] Nexus${RESET} instance as Maven mirror..."
    nexusMirror="https://nexus.alm.gsnetcloud.corp"
    ;;
  "alm-multi-cloud-pro-no-proxy")
    info "Using ${GREEN}ALM Multi-Cloud [PRO] (no proxy) Nexus${RESET} instance as Maven mirror..."
    nexusMirror="http://ccccn000058.cloudcenter.corp:8081"
    ;;
  *)
    error "Unknown target Nexus instance '${YELLOW}${targetNexus}${RESET}'. It should be one of '${CYAN}alm-multi-cloud-pro${RESET}' or '${CYAN}alm-global-pro${RESET}'."
    exit 5
esac

logPrefix="   |  "
(( QUIET )) && {
  logPrefix=""
}

######
##
## Main
##
######

info ">> Launching BATS..."
docker run --rm -m 2048m \
  -e JAVA_OPTS="-Xmx2048m -Xms512m" \
  -e MAVEN_OPTS="-Xmx2048m -Xms512m" \
  -e MVN_EXTENSION_URL="${extensionUrl}" \
  -v $(pwd)/:/home/jenkins/test \
  --user 1000 \
  registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent:latest \
    sh -c "extensionName='${extensionName}' mirror='${nexusMirror}' /home/jenkins/test/bats-core/bin/bats test" 2>&1 | \
  sed "s/^/${logPrefix}/"
