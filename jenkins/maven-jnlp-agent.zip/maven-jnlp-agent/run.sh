docker run --rm -m 2048m \
  -e MVN_EXTENSION_URL=https://nexus.alm.gsnetcloud.corp/repository/maven-releases/com/santander/alm/almglobal-maven-lifecycle/1.2.0/almglobal-maven-lifecycle-1.2.0.jar \
  --user 1000:1000 \
   registry.global.ccc.srvb.can.paas.cloudcenter.corp/c3alm-sgt/maven-jnlp-agent:latest sh -c 'ls -la $MAVEN_HOME/lib/ext'
